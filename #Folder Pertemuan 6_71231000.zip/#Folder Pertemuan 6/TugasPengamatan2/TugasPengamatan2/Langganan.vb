﻿Public Class Langganan
    Private Sub lblNamaPelanggan_Click(sender As Object, e As EventArgs) Handles lblNamaPelanggan.Click

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblKendaraanPelanggan.Click

    End Sub

    Private Sub btnTutup_Click(sender As Object, e As EventArgs) Handles btnTutup.Click
        Utama.Show()
        Me.Hide()
    End Sub
End Class