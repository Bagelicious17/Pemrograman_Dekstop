﻿Public Class UbahProfil
    Private Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click
        Utama.Show()
        Me.Hide()
    End Sub

    Private Sub btnTutup_Click(sender As Object, e As EventArgs) Handles btnTutup.Click
        Utama.Show()
        Me.Hide()
    End Sub
End Class