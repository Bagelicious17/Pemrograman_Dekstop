﻿Public Class Laporan_Pendapatan_Parkir
    Private Sub btnTutup_Click(sender As Object, e As EventArgs) Handles btnTutup.Click
        Utama.Show()
        Me.Hide()
    End Sub
End Class